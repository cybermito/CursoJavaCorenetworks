package supuestoPracticoFinal1;
//Esta clase servira para comprobar el funcionamiento de las clases anteriores en los supuestos dados en cada ejercicio. 
public class TestAtletismo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
